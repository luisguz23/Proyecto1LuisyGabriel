//
// Source code recreated from a .class file by IntelliJ IDEA
// (powered by FernFlower decompiler)
//

package p.proyectomegafinal;

import java.util.Iterator;
import javafx.application.Application;
import javafx.collections.ObservableList;
import javafx.geometry.Insets;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ListView;
import javafx.scene.control.SelectionMode;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

public class Main extends Application {
    Stage window;
    Scene scene;
    Button button;
    ListView<String> listView;

    public Main() {
    }

    public static void main(String[] args) {
        launch(args);
    }

    public void start(Stage primaryStage) throws Exception {
        this.window = primaryStage;
        this.window.setTitle("thenewboston");
        this.button = new Button("submit");
        this.listView = new ListView();
        this.listView.getItems().addAll(new String[]{"Iron Man", "Titanic", "Contact", "Surrogates"});
        this.listView.getSelectionModel().setSelectionMode(SelectionMode.MULTIPLE);
        this.button.setOnAction((e) -> {
            this.buttonClicked();
        });
        VBox layout = new VBox(10.0);
        layout.setPadding(new Insets(20.0, 20.0, 20.0, 20.0));
        layout.getChildren().addAll(new Node[]{this.listView, this.button});
        this.scene = new Scene(layout, 300.0, 250.0);
        this.window.setScene(this.scene);
        this.window.show();
    }

    public void buttonClicked() {
        String message = "";
        ObservableList<String> movies = this.listView.getSelectionModel().getSelectedItems();

        String m;
        for(Iterator var3 = movies.iterator(); var3.hasNext(); message = message + m + "\n") {
            m = (String)var3.next();
        }

        System.out.println(message);

    }
}
