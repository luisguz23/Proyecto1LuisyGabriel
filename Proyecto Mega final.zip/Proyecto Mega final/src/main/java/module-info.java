module p.proyectomegafinal {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.xml;
    requires java.logging;


    opens p.proyectomegafinal to javafx.fxml;
    exports p.proyectomegafinal;
}